#pragma once
#include <unordered_map>
#include "GenericClass.h"
#include <string>

namespace jbon {
	class ClassCollection
	{
		//friend the file function that saves class collections
		std::unordered_map<std::string, GenericClass> classes;
	public:	
		ClassCollection();
		void push_back(const GenericClass& genericClass);
		GenericClass& operator[](std::string key);
		int size();
		//strings
		std::string serialize();
		friend std::ostream& operator<< (std::ostream& stream, ClassCollection& collection);
	};
}
