#pragma once
#include <unordered_map>
#include "value.h"
#include "ClassObject.h"
#include "ValueType.h"
#include <string>
#include <vector>
//might be an error because copying over iterators
namespace jbon {
	class Object :
		public ClassObject,
		public ValueTypeContract<Object>
	{
	private:
		friend class ValueTypeContract<Object>;
		friend class ValueRegistration<Object>;		
		static bool isSameType(std::string str);
		static Object * create(std::string str);
		static std::pair<char, char> getSurroundingDelimeters();
		//everything has to be a pointer because thats what's used
	public:
		
		Object();
		Object(std::string input);
		//copying
		Object(const Object& other);
		Object& operator=(const Object& other);
		//serializable functions
		std::string serialize() const;
		template <typename T>
		void emplace(std::string key, T value) {
			push_back(key, Value::make<T>(value));
		}
		void erase(std::string key);
		friend std::ostream& operator<<(std::ostream& stream, const Object& object);

		/*class anyPair;

		template <typename ... args>
		static Object make(std::pair<std::string, args>... values) {
			Object result;
			result.add(values...);
			return result;
		}*/
		/*
		template <typename ... args>
		static Object make(std::pair<const char *, args>... values) {
			Object result;
			result.add(values...);
			return result;
		}
		*/
	private:

		//template<typename T, typename ...args>
		//	//typename = std::enable_if< std::is_same<typename T::first_type, std::string>::value>>
		//	void add(std::pair<std::string, T> value, std::pair<std::string, args>... values) {
		//	emplace(value.first, Value::make(value.second));
		//	add(values...);
		//}
		//template<typename T>
		//	//typename = std::enable_if< std::is_same<typename T::first_type, std::string>::value>>
		//	void add(std::pair<std::string, T> value) {
		//	emplace(value.first, Value::make(value.second));
		//}
		//template<typename T, typename ...args>
		////typename = std::enable_if< std::is_same<typename T::first_type, std::string>::value>>
		//void add(std::pair<const char *, T> value, std::pair<const char *, args>... values) {
		//	emplace(value.first, Value::make(value.second));
		//	add(values...);
		//}
		//template<typename T>
		////typename = std::enable_if< std::is_same<typename T::first_type, std::string>::value>>
		//void add(std::pair<const char *, T> value) {
		//	emplace(value.first, Value::make(value.second));
		//}
		//typename = std::enable_if_t < (std::is_convertible_v<args&, std::pair<std::string, typename T::second_type>> && ...)>
		//typename = std::enable_if_t < (std::is_convertible_v<T, std::pair<std::string, typename T::second_type>>)>
	};
}

