#pragma once
#include "ClassObject.h"
#include <algorithm>
#include <functional>
#include "ObjectCollection.h"

namespace jbon {
	class GenericClass
	{
	private:
		std::string className;
		std::vector<std::string> keys; //all the keys from the schema
		ObjectCollection objects;
		ClassObject& addObject(const ClassObject& object);
	public:

		//constructor and yea
		GenericClass(std::string schema);
		GenericClass();

		//get the associated objects
		ObjectCollection& getObjects();

		//serialization/string functions
		std::string serialize() const;
		std::string name() const;
		friend std::ostream& operator<< (std::ostream& stream, GenericClass& genericClass);

		//functions for making new object
		template<typename...args>
		ClassObject& constructObject(args...list) {
			if (keys.size() != sizeof...(list)) {
				std::cerr << "Generic Class " << className << " has " << keys.size() <<
					" parameters, but was only constructed with " << sizeof...(list) << std::endl;
				throw;
			}
			ClassObject classObject;
			push_backOnObject(classObject, 0, list...);
			return addObject(classObject);
		}
		template<typename...args>
		ClassObject& constructNamedObject(std::string name, args...list) {
			auto& object = constructObject(list...);
			object.objectName = std::make_unique<std::string>(name);
			return object;
		}
		ClassObject& constructObject(std::string data); //parses through data to add object
		ClassObject& constructObject(std::vector<Value> values);
		ClassObject& constructNamedObject(std::string name, std::vector<Value> values);
		
		//some sneaky template garbage
	private:
		template<typename T>
		void push_backOnObject(ClassObject& object, int key, T value) {
			object.push_back(keys.at(key), Value::make(value));
		}
		//allows to add parameter packs to an object
		template<typename T, typename...args>
		void push_backOnObject(ClassObject& object, int key, T value, args...list){
			object.push_back(keys.at(key), Value::make(value));
			push_backOnObject(object, ++key, list...);
		}
		
	};
}
