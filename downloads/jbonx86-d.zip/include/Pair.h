#pragma once
#include "ValueType.h"
#include "value.h"

namespace jbon {
	class Pair : 
		public ValueTypeContract<Pair>
	{
		friend class ValueTypeContract<Pair>;
		friend class ValueRegistration<Pair>;
		static Pair * create(std::string str);
		static bool isSameType(std::string str);
		static std::pair<char, char> getSurroundingDelimeters();

		Value first, second;
	public:
		template <typename T, typename U>
		static Pair make(T first, U second) {
			Pair result;
			result.first = Value::make(first);
			result.second = Value::make(second);
			return result;
		}
		std::string serialize() const;

		Pair(std::string str);
		Pair();
		~Pair();
		template<typename T>
		T& key() {
			return first.get<T>();
		}
		template<typename T>
		T& value() {
			return second.get<T>();
		}
		//setting
		template<typename T>
		void setKey(const T& key) {
			return first = Value::make(key);
		}
		template<typename T>
		void setValue(const T& value) {
			return second = Value::make(value);
		}
		void swap();
		
	};
}
